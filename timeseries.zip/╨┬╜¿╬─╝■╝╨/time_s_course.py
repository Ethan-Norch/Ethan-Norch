import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
import math
from scipy.optimize import minimize
def statespacegen(param):
    sigmae = abs(param[0])
    sigmau = abs(param[1])
    z = param[2]
    w=param[3]
    const = param[4]
    n = param[5]
    e = math.sqrt(sigmae)*np.random.random(n)
    u = math.sqrt(sigmau)*np.random.random(n)
    y = np.zeros(n)
    alpha = np.zeros(n)
    y[0] = e[0]
    alpha[0] = u[0]
    for i in range(2,n):
        y[i] = z*alpha[i-1] +e[i]
        alpha[i] = const+w*alpha[i-1]+u[i]
    return y,alpha
def KF(param,series):
    sigmae = param[0]
    sigmau = param[1]
    z = param[2]
    w = param[3]
    const = param[4]
    n = len(series)
    a = np.zeros(n)
    p = np.zeros(n)
    a[0] = series[0]
    p[0] = 10000
    if w<0:
        a[0] = 0
        p[0] = sigmau/(1-w**2)
    k = np.zeros(n)
    v = np.zeros(n)
    for t in range(2, n):
        k[t] = (z * w * p[t - 1]) / (z**2 * p[t - 1] + sigmae)
        p[t] = w**2 * p[t - 1] - w * z * k[t] * p[t - 1] + sigmau
        v[t] = series[t] - z * a[t - 1]
        a[t] = const + w * a[t - 1] + k[t] * v[t]
    return a,v,k,p
def LoglikeSS(param):
    sigmae = abs(param[0])
    sigmau = abs(param[1])
    w = abs(param[2])
    const = abs(param[3])
    z = 1
    n = len(y)
    a = np.zeros(n)
    p = np.zeros(n)
    a[0] = y[0]
    p[0] = 10000
    if (w < 1):
        a[0]=0
        p[0] = sigmau / (1-w**2)
    k = np.zeros(n)
    v = np.zeros(n)
    likelihood = 0
    for t in range(2,n):
        k[t] = (z * w * p[t - 1]) / (z**2 * p[t - 1] + sigmae)
        p[t] = w ** 2 * p[t-1]-w * z * k[t] * p[t-1]+sigmau
        v[t] = y[t]-z * a[t-1]
        a[t] = const+w * a[t-1]+k[t] * v[t]
        likelihood = likelihood+0.5 * math.log(2 * math.pi)+0.5 * math.log(z**2 * p[t-1]+sigmae)+0.5 * (v[t]**2 / (z ** 2 * p[t-1]+sigmae))
    return likelihood
def LoglikeSSconc(param):
    q = abs(param[0])
    w = abs(param[1])
    const = abs(param[2])
    z = 1
    n = len(y)
    a = np.zeros(n)
    p = np.zeros(n)
    a[0] = y[0]
    p[0] = 10000
    if (w < 1):
        a[0]=0
        p[0] = sigmau / (1-w**2)
    k = np.zeros(n)
    v = np.zeros(n)
    likelihood = 0
    sigmae = 0
    for t in range(2,n):
        k[t] = (z * w * p[t - 1]) / (z**2 * p[t - 1] + sigmae)
        p[t] = w ** 2 * p[t-1]-w * z * k[t] * p[t-1]+sigmau
        v[t] = y[t]-z * a[t-1]
        a[t] = const+w * a[t-1]+k[t] * v[t]
        sigmae = sigmae+(v[t]**2/(z**2*p[t-1]+1))
        likelihood = likelihood+0.5 * math.log(2 * math.pi)+0.5+0.5 * math.log(z**2 * p[t-1]+1)
    return likelihood+0.5*n*math.log(sigmae/n)
def Myparam(param,y):
    q = param[0]
    w = param[1]
    const = param[2]
    z = 1
    n = len(y)
    a = np.zeros(n)
    p = np.zeros(n)
    k = np.zeros(n)
    v = np.zeros(n)
    a[0] = y[0]
    p[0] = 10000
    sigmae =0
    if w<1:
        a[0] = 0
        p[0]=q/(1-w**2)
    for t in range(2,n):
        k[t] = (z * w * p[t - 1]) / (z**2 * p[t - 1] + 1)
        p[t] = w ^ 2 * p[t-1]-w * z * k[t] * p[t-1]+q
        v[t] = y[t]-z * a[t-1]
        a[t] = const+w * a[t-1]+k[t] * v[t]
        sigmae = sigmae + (v[t]**2/(z**2*p[t-1]+1))
    return sigmae/n,q*(sigmae/n),w,const
# sigmae = 0.8
# sigmau = 0.2
# z=1
# w=0.9
# const=0.2
# n=100
# list = [sigmae, sigmau,z,w,const,n]
# y = statespacegen(list)[0]
# plt.plot(y,'r-',label='y')
# paratrue = [sigmae,sigmau,w,const]
# param = [0.6,0.1,0.8,0.3]
# results = minimize(LoglikeSS,np.array(param))
# print(results.x)
# newp = results.x.tolist()
# newp.insert(2,z)
# newp.append(n)
# print(newp)
# plt.plot(statespacegen(newp)[0],'g-',label='ny')
# plt.legend()
# plt.show()
# list = [0.5,0.1,1,0.8,3,100]
# data = statespacegen(list)
# plt.figure(figsize=(15,7))
# plt.plot(data[0],"r-",label='y')
# plt.plot(data[1],"g-",label='alpha')
# plt.plot(KF(list,data[1])[0],'b-',label='a')
# plt.legend()
# plt.show()
#=================exponential smoothing
# def LikeExpSmooth(param):
#   sigmae=abs(param[0])
#   sigmau=abs(param[1]);
#   z=1
#   w=1
#   n=len(y)
#   a = np.zeros(n)
#   p = np.zeros(n)
#   k = np.zeros(n)
#   v = np.zeros(n)
#   const=0
#   a[0]=y[0]
#   p[0]=10000
#   if(w<1):
#       a[0]=0
#       p[0]=sigmau/(1-w**2)
#   likelihood=0
#   for t in range(2,n):
#     k[t]=(z*w*p[t-1])/(z**2*p[t-1]+sigmae)
#     p[t]=w**2*p[t-1]-w*z*k[t]*p[t-1]+sigmau
#     v[t]=y[t]-z*a[t-1]
#     a[t]=const+w*a[t-1]+k[t]*v[t]
#     likelihood=likelihood+0.5*math.log(2*math.pi)+0.5*math.log(z**2*p[t-1]+sigmae)+0.5*(v[t]**2/(z**2*p[t-1]+sigmae))
#   return likelihood
#
# def LikeExpSmoothconc(param):
#   q=abs(param[0])
#   const=0
#   z=1
#   w=1
#   n=len(y)
#   a = np.zeros(n)
#   p = np.zeros(n)
#   k = np.zeros(n)
#   v = np.zeros(n)
#   const=0
#   a[0]=y[0]
#   p[0]=10000
#   if(w<1):
#       a[0]=0
#       p[0]=sigmau/(1-w**2)
#   likelihood=0
#   sigmae = 0
#   for t in range(2,n):
#     k[t]=(z*w*p[t-1])/(z**2*p[t-1]+1)
#     p[t]=w**2*p[t-1]-w*z*k[t]*p[t-1]+q
#     v[t]=y[t]-z*a[t-1]
#     a[t]=const+w*a[t-1]+k[t]*v [t]
#     sigmae = sigmae +(v[t]**2/(z**2*p[t-1]+1))
#     likelihood=likelihood+0.5*math.log(2*math.pi)+0.5*math.log(z**2*p[t-1]+1)
#   return likelihood+0.5*n*math.log(sigmae/n)
#
# def MyparamExpSmo(para):
#     q=para[0]
#     w=1
#     co=0
#     z=1
#     n=len(y)
#     a = np.zeros(n)
#     p = np.zeros(n)
#     k = np.zeros(n)
#     v = np.zeros(n)
#     a[0]=y[0]
#     p[0]=10000
#     if w<1:
#         a[0]=0
#         p[0]<-q/(1-w**2)
#     sigmae=0
#     for t in range(2,n):
#         k[t]=(z*w*p[t-1])/(z**2*p[t-1]+1)
#         p[t]=w**2*p[t-1]-w*z*k[t]*p[t-1]+q
#         v[t]=y[t]-z*a[t-1]
#         a[t]=co+w*a[t-1]+k[t]*v[t]
#         sigmae=sigmae+(v[t]**2/(z**2*p[t-1]+1))
#     return sigmae/(n-1),q*(sigmae/(n-1)),w,co
#
# sigmae = 0.5
# sigmau = 0.2
# z=1
# w=1
# const=0
# n=100
# list = [sigmae,sigmau,z,w,const,n]
# y = statespacegen(list)[0]
# plt.plot(y,'r-',label='y')
# results = minimize(LikeExpSmooth,[0.7,0.3]).x.tolist()
# results.append(z)
# results.append(w)
# results.append(const)
# results.append(n)
# print(results)
# dat = statespacegen(results)[0]
# plt.plot(dat,'y-',label='exponentialSmooth')
# resultsconc = MyparamExpSmo(minimize(LikeExpSmoothconc,[0.5]).x.tolist())
# re =[0,0,0,0]
# for i in range(4):
#     re[i] = resultsconc[i]
#
# re.insert(2,z)
# re.append(n)
# plt.plot(statespacegen(re)[0],'g-',label='exponentialSmoothConc')
# plt.legend()
# plt.show()
ads = pd.read_csv('currency.csv',index_col=['Time'], parse_dates=['Time'])
y=[]
for i in range(len(ads.values)):
    y.append(ads.values[i][0])
print(y)
plt.plot(y)
plt.show()
# # ===============Theta method==============
# def LikeTheta(param):
#     sigmae=abs(param[0])
#     sigmau=abs(param[1])
#     const=abs(param[2])
#     z=1
#     w=1
#     n=len(y)
#     a = np.zeros(n)
#     p = np.zeros(n)
#     k = np.zeros(n)
#     v = np.zeros(n)
#     a[0]=y[0]
#     p[0]=10000
#     likelihood=0
#     for t in range(2,n):
#         k[t]=(z*w*p[t-1])/(z**2*p[t-1]+sigmae)
#         p[t]=w**2*p[t-1]-w*z*k[t]*p[t-1]+sigmau
#         v[t]=y[t]-z*a[t-1]
#         a[t]=const+w*a[t-1]+k[t]*v[t]
#         likelihood=likelihood+0.5*math.log(2*math.pi)+0.5*math.log(z**2*p[t-1]+sigmae)+0.5*(v[t]**2/(z**2*p[t-1]+sigmae))
#     return likelihood
# result = minimize(LikeTheta,[0.7,0.3,0.2]).x.tolist()
# result.insert(2,1)
# result.insert(2,1)
# result.append(len(y))
# plt.plot(statespacegen(result)[0],'b-',label='theta')
# plt.legend()
# plt.show()

# =====================AR==================
# n=100
# e=np.random.random(n)
# gamma=0.2
# w=0.94
# y=np.zeros(n)
# alpha=np.zeros(n)
# y[0] = e[0]
# alpha[0] = e[0]
# for t in range(2,n):
#     y[t] = alpha[t-1]+e[t]
#     alpha[t]=w*alpha[t-1]+gamma*e[t]
# plt.plot(y,'r',label='y')
# plt.plot(alpha,'g',label='alpha')
# plt.legend()
# plt.show()
# a=np.zeros(len(y))
# a[0]=0
# ee=np.zeros(len(y))
# def fu(param):
#     gama=abs(param[0])
#     w=abs(param[1])
#     sum = 0
#     for t in range(2,len(y)):
#         ee[t] = y[t] - a[t-1]
#         a[t] = w*a[t-1]+gama*ee[t]
#     for i in ee:
#         sum = sum+i**2
#     return sum/len(y)
# results = minimize(fu,[0,0]).x.tolist()
# print(results)
# e=np.random.random(n)
# ny=np.zeros(len(y))
# alpha = np.zeros(n)
# gamma = results[0]
# w=results[1]
# for t in range(2,n):
#      ny[t] = alpha[t-1]+e[t]
#      alpha[t]=w*alpha[t-1]+gamma*e[t]
# plt.plot(y, 'r', label='y')
# plt.plot(ny,'g',label='ny')
# plt.legend()
# plt.show()

# ===================damped trend model===========
n=100
e = math.sqrt(0.6)*np.random.random(n)
gamma=0.4
theta=0.2
phi=0.7
y=np.zeros(n)
alpha=np.zeros(n)
beta=np.zeros(n)
y[0]=e[0]
alpha[0]=e[0]
beta[0]=0
for t in range(2,n):
    beta[t]=phi*beta[t-1]+theta*e[t]
    alpha[t]=alpha[t-1]+phi*beta[t-1]+gamma*e[t]
    y[t]=alpha[t-1]+phi*beta[t-1]+e[t]
plt.figure()
plt.title('damped trend')
plt.plot(y,'r',label='y')
plt.plot(alpha,'g',label='alpha')
plt.plot(beta,'b',label='beta')
plt.legend()
plt.show()
a=np.zeros(n)
b=np.zeros(n)
b[0]=0
a[0]=y[0]
ee=np.zeros(n)
def fu(param):
    gama=abs(param[0])
    theta=abs(param[1])
    phi=abs(param[2])
    sum = 0
    for t in range(2,len(y)):
        ee[t] = y[t] - a[t-1] - phi*b[t-1]
        a[t] = a[t-1]+phi*b[t-1]+gama*ee[t]
        b[t] = phi*b[t-1]+theta*ee[t]
    for i in ee:
        sum = sum+i**2
    return sum/len(y)
resu = minimize(fu,[0.2,0.1,0.8]).x.tolist()
print(resu)
# e = math.sqrt(0.6)*np.random.random(n)
gamma=resu[0]
theta=resu[1]
phi=resu[2]
ny=np.zeros(n)
nalpha=np.zeros(n)
nbeta=np.zeros(n)
ny[0]=e[0]
nalpha[0]=e[0]
nbeta[0]=0
for t in range(2,n):
    nbeta[t]=phi*nbeta[t-1]+theta*e[t]
    nalpha[t]=nalpha[t-1]+phi*nbeta[t-1]+gamma*e[t]
    ny[t]=nalpha[t-1]+phi*nbeta[t-1]+e[t]
plt.figure()
plt.title('damped trend')
plt.plot(y,'g',label='y')
plt.plot(ny,'r',label='ny')
plt.legend()
plt.show()

