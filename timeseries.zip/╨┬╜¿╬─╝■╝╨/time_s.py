import xlrd
import numpy as np
from matplotlib import pyplot as plt
import math
import csv
# excel = 'Table_2.1_Energy_Consumption_by_Sector.xlsx'
# Excel = xlrd.open_workbook(excel,encoding_override="utf-8")
# sheet = Excel.sheet_by_name('Monthly Data')
# print(sheet.nrows)
# primary = sheet.col_values(1)[12:400]
# with open('time_series_covid19_confirmed_US.csv','r') as f:
#     covGum=[]
#     covidUS = csv.reader(f)
#     covidGum = list(covidUS)[2][20:170]
#     covGum= list(map(float,covidGum))
# print(covGum)

# print(primary)
# from matplotlib import pyplot as plt
# primary = np.array(primary)
# plt.plot(primary)
# plt.show()
# plt.hist(primary,bins=20)
# plt.show()
#
# def BC(array,labmda):
#     y = []
#     print(array)
#     if labmda==0:
#         for i,item in enumerate(array):
#             if i == 0:
#                 print(i,item)
#             y.append(math.log(item))
#     else:
#         for i,item in enumerate(array):
#             y[i] = (item**labmda-1)/labmda
#     # print(y)
#     return(y)
# p = BC(primary,0)
#
# plt.plot(p)
# plt.show()
# def SP(data,lam):
#     sgn = lambda x:1 if x>0 else x-1 if x<0 else 0
#     y=[]
#     if lam < 0 :
#         print("lambda should be over 0")
#         return 0
#     else:
#
#         for i,item in enumerate(data):
#             y.append((sgn(item)*abs(item**lam)-1)/lam)
#     return y
# def GP(series,lam):
#     y=[]
#     for i,item in enumerate(series):
#         if item>=0:
#             if lam==0:
#                 y.append(math.log(item+1))
#             else:
#                 y.append(((item + 1) ** lam - 1) / lam)
#         else:
#             if lam==2:
#                 y.append(-math.log(-item+1))
#             else:
#                 y.append(-((-item+1)**(2-lam)-1)/(2-lam))
#     return(y)
# def IHS(series,lam):
#     if lam<=0:
#         print("lambda should be over 0")
#         return 0
#     else:
#         y=[]
#         for i,item in enumerate(series):
#             y.append(math.log((lam*item+lam**2*item**2+1)/lam))
#     return(y)
#
# priDiff1 = np.diff(primary,1)
# priDiff2 = np.diff(primary,2)
# plt.plot(priDiff1,color="b")
# plt.plot(priDiff2,color="g")
# plt.show()

# def smooth(a,WSZ):
#   # WSZ is an odd
#   out0 = np.convolve(a,np.ones(WSZ,dtype=int),'valid')/WSZ
#   r = np.arange(1,WSZ-1,2)
#   start = np.cumsum(a[:WSZ-1])[::2]/r
#   stop = (np.cumsum(a[:-WSZ:-1])[::2]/r)[::-1]
#   return np.concatenate(( start , out0, stop ))
# plt.plot(primary[0:200],color="r",label='energy')
# plt.plot(smooth(primary[0:200],13),label='smooth')
# plt.plot(primary[0:200]-np.array(smooth(primary[0:200],13)),color="b",label='trend')
# plt.legend()
# plt.show()


with open('ads.csv') as f:
    ACSF1 = csv.reader(f)
    iap = list(ACSF1)[1:145]
    Iap=[]
    print(len(iap))
    for row in iap:
      Iap.append(row[1])
    IAP = list(map(float,Iap))
# print(IAP)
# # print(Ac)
# plt.plot(IAP)
# plt.show()
# import pandas as pd
# # print(Ac)Ac = pd.DataFrame(Ac)
#statinary test4/
import pandas as pd
def rolling_statistics(timeseries,windows):
    # Determing rolling statistics
    TIM = pd.DataFrame(timeseries)
    rolmean = TIM.rolling(window=windows).mean()
    rolstd = TIM.rolling(window=windows).std()
    # Plot rolling statistics:
    orig = plt.plot(TIM, color='blue', label='Original')
    mean = plt.plot(rolmean, color='red', label='Rolling Mean')
    std = plt.plot(rolstd, color='black', label='Rolling Std')
    plt.legend(loc='best')
    plt.title('Rolling Mean & Standard Deviation')
    plt.show(block=False)
# ##ADF检验
from statsmodels.tsa.stattools import adfuller
def adf_test(timeseries,windows):
    rolling_statistics(timeseries,windows)  # 绘图
    print('Results of Augment Dickey-Fuller Test:')
    dftest = adfuller(timeseries)
    dfoutput = pd.Series(dftest[0:4], index=['Test Statistic', 'p-value', '#Lags Used', 'Number of Observations Used'])
    for key, value in dftest[4].items():
        dfoutput['Critical Value (%s)' % key] = value  # 增加后面的显著性水平的临界值
    print(dfoutput)
# # adf_test(IAP,7)
# # adf_test(IAP,30)
# # adf_test(IAP,51)
# from statsmodels.stats.diagnostic import acorr_ljungbox
# def test_stochastic(ts,lag):
#     p_value = acorr_ljungbox(ts, lags=lag) #lags可自定义
#     return p_value
# # test_stochastic(IAP,24)
# #
####自相关图ACF和偏相关图PACF
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf

def acf_pacf_plot(ts_log_diff):
    plot_acf(ts_log_diff, lags=24).show()  # ARIMA,q
    plot_pacf(ts_log_diff, lags=24).show() # ARIMA,p
# acf_pacf_plot(IAP)  # 查看数据的自相关图和偏自相关图

from statsmodels.tsa.arima_model import ARMA

#
# def proper_model(data_ts, maxLag):
#     init_bic = float("inf")
#     init_p = 0
#     init_q = 0
#     init_properModel = None
#     t=0
#     for p in np.arange(maxLag):
#         for q in np.arange(maxLag):
#             t=t+1
#             # print(t,p,q)
#             model = ARMA(data_ts, order=(p, q))
#             try:
#                 results_ARMA = model.fit()
#             except:
#                 continue
#             bic = results_ARMA.bic
#             if bic < init_bic:
#                 init_p = p
#                 init_q = q
#                 init_properModel = results_ARMA
#                 init_bic = bic
#                 return init_bic, init_p, init_q, init_properModel
# # proper_model(IAP, 24)
# # b
# import pandas as pd
# with open('international-airline-passengers/international-airline-passengers.csv') as f:
#     air = list(csv.reader(f))[1:140]
#     Air = [row[1] for row in air]
#     AIR = list(map(float,Air))
# plt.plot(AIR)
# plt.show()
# #
# import statsmodels.api as sm
# from statsmodels.tsa.seasonal import seasonal_decompose
#
# decomposition = seasonal_decompose(AIR,freq=24)
# fig=plt.figure()
# fig=decomposition.plot()
# plt.show()
# # # 季节性很明显
# trend = decomposition.trend
# seasonal = decomposition.seasonal
# residual = decomposition.resid
# adf_test(AIR,12)
# # nonstationary
# airline = pd.DataFrame({'air':AIR})
# print(airline)
# # FIRSTDIFF
# airline['firstDiff'] = airline.air-airline.air.shift(1)
# firstDiff=[item for i,item in enumerate(list(airline.firstDiff)) if i !=0]
# adf_test(firstDiff,12)
# # SEASONDIFF
# airline['seaDiff'] = airline.air-airline.air.shift(12)
# seaDiff=[item for i,item in enumerate(list(airline.seaDiff)) if i >12]
# adf_test(seaDiff,12)
# # SEASINFIRSTDIFF
# airline['seaFirstDiff'] = airline.firstDiff - airline.firstDiff.shift(12)
# seaFirstDiff=[item for i,item in enumerate(list(airline.firstDiff)) if i >12]
# adf_test(seaFirstDiff,12)
# # LOG
# airline['log'] = airline.air.apply(lambda x:np.log(x))
# arilog = [i for i in list(airline.log)]
# adf_test(arilog,12)
# #
# fig = plt.figure(figsize=(12,8))
# ax1 = fig.add_subplot(211)
# fig = sm.graphics.tsa.plot_acf(seaFirstDiff, lags=40, ax=ax1)
# ax2 = fig.add_subplot(212)
# fig = sm.graphics.tsa.plot_pacf(seaFirstDiff, lags=40, ax=ax2)
# plt.show()
# # #
# mod = sm.tsa.statespace.SARIMAX(airline.air, trend='n', order=(0,1,0), seasonal_order=(1,1,1,12))
# results = mod.fit()
# print(results.summary())
# airline['forcast'] = results.predict(start=120,end=140,dynamic=True)
# print(airline.forcast)
# plt.plot(list(airline.forcast),color='r')
# plt.plot(AIR)
# plt.show()

# 平滑：一次指数平滑法
import pandas as pd
ads = pd.read_csv(r'ads.csv', index_col=['Time'], parse_dates=['Time'])
# # # 3 预测质量指标（forecast quality metrics),引入相关指标
from sklearn.metrics import r2_score, mean_absolute_error, median_absolute_error
from sklearn.metrics import mean_squared_error, mean_squared_log_error
def mean_absolute_percentage_error(y_true, y_pred):
    return np.mean(np.abs((y_true - y_pred) / y_true)) * 100
def exponential_smoothing(series, alpha):
    """
    series:dataset with timestamps
    alpha:float [0.0,1.0], smoothing parameter
    """
    result=[]
    result.append(series[0])  # first values is same as series
    for n in range(1, len(series)):
        result.append(alpha * series[n] + (1 - alpha) * result[n - 1])
    return result

def plotExponentialSmoothing(series, alphas):
    """
    Plot exponential smoothing with different alphas
    series:dataset with timestamps
    alpha:list of floats, smoothing parameters
    """
    with plt.style.context('seaborn-white'):
        plt.figure(figsize=(15, 7))
        for alpha in alphas:
            plt.plot(exponential_smoothing(series, alpha), label='Alpha {}'.format(alpha))
        plt.plot(series.values, 'c', label='Actual')
        plt.legend(loc='best')
        plt.axis('tight')
        plt.title('Exponential Smoothing')
        plt.grid(True)
        plt.show()

#-------------------------------------------------------------------------------------
plotExponentialSmoothing(ads.Ads, [0.3, 0.05])

#=====================================================================================

#  平滑：双指数平滑法
def double_exponential_smoothing(series, alpha, beta):
    """
    series:dataset with timeseries
    alpha:float[0.0,1.0], smoothing parameter for level
    beta:float[0.0,1.0], smoothing parameter for trend
    """
    #  first value is same as series
    result = [series[0]]
    for n in range(1, len(series) + 1):
        if n == 1:
            level, trend = series[0], series[1] - series[0]
        if n >= len(series):
            value = result[-1]
        else:
            value = series[n]
        last_level, level = level, alpha * value + (1 - alpha) * (level + trend)
        trend = beta * (level - last_level) + (1 - beta) * trend
        result.append(level + trend)
    return result


def plotDoubleExponentialSmoothing(series, alphas, betas):
    """
    Plot double exponential smoothing with different alphas and betas
    series:dataset with timestamps
    alphas:list of floats, smoothing parameters for level
    betas:list of floats, smoothing parameters for trend
    """
    with plt.style.context('seaborn-white'):
        plt.figure(figsize=(15, 7))
        for alpha in alphas:
            for beta in betas:
                plt.plot(double_exponential_smoothing(series, alpha, beta),
                         label='Alpha {}, Beta {}'.format(alpha, beta))
        plt.plot(series.values, label='Actual')
        plt.legend(loc='best')
        plt.axis('tight')
        plt.title('Double Exponential Smoothing')
        plt.grid(True)
        plt.show()
#-------------------------------------------------------------------------------------
plotDoubleExponentialSmoothing(ads.Ads, alphas=[0.9, 0.02], betas=[0.9, 0.02])

#
# #=====================================================================================
#
# # 平滑：三次指数平滑法
def exponential_smoothing_3(alpha, s):
    s_single = exponential_smoothing(s, alpha)
    s_double = exponential_smoothing(s_single, alpha)
    s_triple = exponential_smoothing(s_double, alpha)
    a_triple = [0 for i in range(len(s))]
    b_triple = [0 for i in range(len(s))]
    c_triple = [0 for i in range(len(s))]
    for i in range(len(s)):
        a_triple[i] = 3 * s_single[i] - 3 * s_double[i] + s_triple[i]
        b_triple[i] = (alpha / (2 * ((1 - alpha) ** 2))) * (
                    (6 - 5 * alpha) * s_single[i] - 2 * ((5 - 4 * alpha) * s_double[i]) + (4 - 3 * alpha) * s_triple[i])
        c_triple[i] = ((alpha ** 2) / (2 * ((1 - alpha) ** 2))) * (s_single[i] - 2 * s_double[i] + s_triple[i])
    return a_triple, b_triple, c_triple

def predict_value_with_exp_smoothing_3(se, alpha):
    a, b, c = exponential_smoothing_3(alpha, se)
    s_temp = []
    s_temp.append(a[0])
    for i in range(len(a)):
        s_temp.append(a[i] + b[i] + c[i])
    return s_temp
dataset = predict_value_with_exp_smoothing_3(ads.Ads, alpha=0.2)
plt.figure()
plt.plot(ads.Ads.values,label='actual')
plt.plot(dataset,'g-',label='ads.Ads 3 es')
plt.legend(loc='best')
plt.show()
#
# # holtwinters
# # ================================================================
# class HoltWinters:
#     """
#     Holt-Winter model with the anomalies detection using Brutlag method
#     series:initial time series
#     slen:length of a season
#     alpha, beta, gamma:Holt-Winter model coefficients
#     n_preds:predictions horizon
#     scaling_factor:sets the width of the confidence interval by Brutlag (usually take values from 2 to 3)
#     """
#     def __init__(self, series, slen, alpha, beta, gamma, n_preds, scaling_factor=1.96):
#         self.series = series
#         self.slen = slen
#         self.alpha = alpha
#         self.beta = beta
#         self.gamma = gamma
#         self.n_preds = n_preds
#         self.scaling_factor = scaling_factor
#
#     def initial_trend(self):
#         sum = 0.0
#         for i in range(self.slen):
#             sum += float(self.series[i + self.slen] - self.series[i]) / self.slen
#         return sum / self.slen
#
#     def initial_seasonal_components(self):
#         seasonals = {}
#         season_averages = []
#         n_seasons = int(len(self.series) / self.slen)
#         # 计算每个季节平均值
#         for j in range(n_seasons):
#             season_averages.append(sum(self.series[self.slen * j:self.slen * j + self.slen]) / float(self.slen))
#         # 开始计算初始值
#         for i in range(self.slen):
#             sum_of_vals_over_avg = 0.0
#             for j in range(n_seasons):
#                 sum_of_vals_over_avg += self.series[self.slen * j + i] - season_averages[j]
#             seasonals[i] = sum_of_vals_over_avg / n_seasons
#         return seasonals
#
#     def triple_exponential_smoothing(self):
#         self.result = []
#         self.Smooth = []
#         self.Season = []
#         self.Trend = []
#         self.PredictedDeviation = []
#         self.UpperBond = []
#         self.LowerBond = []
#
#         seasonals = self.initial_seasonal_components()
#
#         for i in range(len(self.series) + self.n_preds):
#             if i == 0:  # 成分初始化
#                 smooth = self.series[0]
#                 trend = self.initial_trend()
#                 self.result.append(self.series[0])
#                 self.Smooth.append(smooth)
#                 self.Trend.append(trend)
#                 self.Season.append(seasonals[i % self.slen])
#
#                 self.PredictedDeviation.append(0)
#
#                 self.UpperBond.append(self.result[0] + self.scaling_factor * self.PredictedDeviation[0])
#                 self.LowerBond.append(self.result[0] - self.scaling_factor * self.PredictedDeviation[0])
#
#                 continue
#
#             if i >= len(self.series):  # 预测
#                 m = i - len(self.series) + 1
#                 self.result.append((smooth + m * trend) + seasonals[i % self.slen])
#
#                 # when predicting we increase uncertainty on each step
#                 self.PredictedDeviation.append(self.PredictedDeviation[-1] * 1.01)
#             else:
#                 val = self.series[i]
#                 last_smooth, smooth = smooth, self.alpha * (val - seasonals[i % self.slen]) \
#                                       + (1 - self.alpha) * (smooth + trend)
#                 trend = self.beta * (smooth - last_smooth) + (1 - self.beta) * trend
#                 seasonals[i % self.slen] = self.gamma * (val - smooth) + (1 - self.gamma) * seasonals[i % self.slen]
#                 self.result.append(smooth + trend + seasonals[i % self.slen])
#
#                 # Deviation is calculated according to Brutlag algorithm
#                 self.PredictedDeviation.append(self.gamma * np.abs(self.series[i] - self.result[i])
#                                                + (1 - self.gamma) * self.PredictedDeviation[-1])
#
#             self.UpperBond.append(self.result[-1] + self.scaling_factor * self.PredictedDeviation[-1])
#             self.LowerBond.append(self.result[-1] - self.scaling_factor * self.PredictedDeviation[-1])
#
#             self.Smooth.append(smooth)
#             self.Trend.append(trend)
#             self.Season.append(seasonals[i % self.slen])
from sklearn.model_selection import TimeSeriesSplit
# def timeseriesCVscore(params, series, loss_function=mean_squared_error, slen=24):
#     """
#     Return error on CV
#     params:vector of parameters for optimization
#     series:dataset with timeseries
#     slen:season length for Holt-Winters model
#     """
#     errors = []
#     values = series.values
#     alpha, beta, gamma = params
#
#     tscv = TimeSeriesSplit(n_splits=3)
#
#     # iterating over folds, train model on each, forecast and calculate error
#     for train, test in tscv.split(values):
#         model = HoltWinters(series=values[train], slen=slen, alpha=alpha, beta=beta, gamma=gamma, n_preds=len(test))
#         model.triple_exponential_smoothing()
#         predictions = model.result[-len(test):]
#         actual = values[test]
#         error = loss_function(predictions, actual)
#         errors.append(error)
#     return np.mean(np.array(errors))

# def plotHoltWinters(series, plot_intervals=False, plot_anomalies=False):
#     """
#     series:dataset with timeseries
#     plot_interval:show confidence intervals
#     plot_anomalies:show anomalies
#     """
#
#     plt.figure(figsize=(20, 10))
#     plt.plot(model.result, label='Model')
#     plt.plot(series.values, label='Actual')
#     error = mean_absolute_percentage_error(series.values, model.result[:len(series)])
#     plt.title('Mean Absolute Percentage Error: {0:.2f}%'.format(error))
#
#     if plot_anomalies:
#         anomalies = np.array([np.NaN] * len(series))
#         anomalies[series.values < model.LowerBond[:len(series)]] = \
#             series.values[series.values < model.LowerBond[:len(series)]]
#         anomalies[series.values > model.UpperBond[:len(series)]] = \
#             series.values[series.values > model.UpperBond[:len(series)]]
#         plt.plot(anomalies, 'o', markersize=10, label='Anomalies')
#
#     if plot_intervals:
#         plt.plot(model.UpperBond, 'r--', alpha=0.5, label='Up/Low confidence')
#         plt.plot(model.LowerBond, 'r--', alpha=0.5)
#         plt.fill_between(x=range(0, len(model.result)), y1=model.UpperBond,
#                          y2=model.LowerBond, alpha=0.2, color='lightgrey')
#     plt.vlines(len(series), ymin=min(model.result), ymax=max(model.UpperBond), linestyles='dashed')
#     plt.axvspan(len(series) - 20, len(model.result), alpha=0.3, color='lightgrey')
#     plt.grid(True)
#     plt.axis('tight')
#     plt.legend(loc='best', fontsize=13)
#     plt.show()
#
# from scipy.optimize import minimize
# data = ads.Ads[:-30]
# # alpha\beta\gamma
# param = [0, 0, 0]
# opt = minimize(timeseriesCVscore, x0=param, args=(data, mean_squared_log_error), method='TNC', bounds=(
#     (0, 1), (0, 1), (0, 1)))
# alpha_final, beta_final, gamma_final = opt.x
# print(alpha_final, beta_final, gamma_final)
#
# model = HoltWinters(data, slen=24, alpha=alpha_final, beta=beta_final, gamma=gamma_final, n_preds=50, scaling_factor=3)
# model.triple_exponential_smoothing()
#
# plotHoltWinters(ads.Ads)
# plotHoltWinters(ads.Ads, plot_intervals=True, plot_anomalies=True)
# #
# #
# plt.figure(figsize=(25,5))
# plt.plot(model.PredictedDeviation)
#
# plt.grid(True)
# plt.axis('tight')
# plt.title("Brutlag's predicted deviation" )
# plt.show()

# economy approach
# ==========================================================================

# white_noise = np.random.normal(size=1000)
# with plt.style.context('bmh'):
#     plt.figure(figsize=(15,5))
#     plt.plot(white_noise)
#
# import statsmodels.api as sm
# def plotProcess(n_samples=1000,rho=0):
#     x=w=np.random.normal(size=n_samples)
#     for t in range(n_samples):
#         x[t] = rho*x[t-1]+w[t]
#
#     with plt.style.context('bmh'):
#         plt.figure(figsize=(10,5))
#         plt.plot(x)
#         plt.title('Rho {}\n Dickey-Fuller p-value: {}'.format(rho,round(sm.tsa.stattools.adfuller(x)[1],3)))
# # statespace
# # ==========================================================
# import statsmodels.tsa.api as smt
# def tsplot(y,lags=None,figsize=(12,7),style='bmh'):
#     """
#     Plot time series, its ACF and PACF, calculate Dickey-Fuller test
#     y:timeseries
#     lags:how many lags to include in ACF,PACF calculation
#     """
#     if not isinstance(y, pd.Series):
#         y = pd.Series(y)
#
#     with plt.style.context(style):
#         fig = plt.figure(figsize=figsize)
#         layout=(2,2)
#         ts_ax = plt.subplot2grid(layout, (0,0), colspan=2)
#         acf_ax = plt.subplot2grid(layout, (1,0))
#         pacf_ax = plt.subplot2grid(layout, (1,1))
#
#         y.plot(ax=ts_ax)
#         p_value = sm.tsa.stattools.adfuller(y)[1]
#         ts_ax.set_title('Time Series Analysis Plots\n Dickey-Fuller: p={0:.5f}'.format(p_value))
#         smt.graphics.plot_acf(y,lags=lags, ax=acf_ax)
#         smt.graphics.plot_pacf(y,lags=lags, ax=pacf_ax)
#         plt.tight_layout()
#     plt.show()
#
# tsplot(ads.Ads, lags=60)
# ads_diff = ads.Ads-ads.Ads.shift(24) # 去除季节性
# tsplot(ads_diff[24:], lags=60)
#
# ads_diff = ads_diff - ads_diff.shift(1) # 最终图
# tsplot(ads_diff[24+1:], lags=60)
#
# from itertools import product
#
# # 建模 SARIMA
# # setting initial values and some bounds for them
# ps = range(2,5)
# d=1
# qs=range(2,5)
# Ps=range(0,2)
# D=1
# Qs=range(0,2)
# s=24 #season length
#
# # creating list with all the possible combinations of parameters
# parameters=product(ps,qs,Ps,Qs)
# parameters_list = list(parameters)
# print(parameters)
# print(parameters_list)
# print(len(parameters_list))
# from tqdm import tqdm
#
# def optimizeSARIMA(parameters_list, d,D,s):
#     """
#     Return dataframe with parameters and corresponding AIC
#     parameters_list:list with (p,q,P,Q) tuples
#     d:integration order in ARIMA model
#     D:seasonal integration order
#     s:length of season
#     """
#     results = []
#     best_aic = float('inf')
#
#     for param in tqdm(parameters_list):
#         # we need try-exccept because on some combinations model fails to converge
#         try:
#             model = sm.tsa.statespace.SARIMAX(ads.Ads, order=(param[0], d,param[1]),
#                                               seasonal_order=(param[2], D,param[3], s)).fit(disp=-1)
#         except:
#             continue
#         aic = model.aic
#         # saving best model, AIC and parameters
#         if aic<best_aic:
#             best_model = model
#             best_aic = aic
#             best_param = param
#         results.append([param, model.aic])
#
#     result_table = pd.DataFrame(results)
#     result_table.columns = ['parameters', 'aic']
#     # sorting in ascending order, the lower AIC is - the better
#     result_table = result_table.sort_values(by='aic',ascending=True).reset_index(drop=True)
#
#     return result_table
#
# result_table = optimizeSARIMA(parameters_list, d,D,s)
# print("result_ttable is",result_table)
# result_table.head()
# p,q,P,Q = result_table.parameters[0]
# best_model = sm.tsa.statespace.SARIMAX(ads.Ads, order=(p,d,q),seasonal_order=(P,D,Q,s)).fit(disp=-1)
# print(best_model.summary())
#
# # inspect the residuals of the model
# tsplot(best_model.resid[24+1:], lags=60)
#
# def plotSARIMA(series, model, n_steps):
#     """
#     plot model vs predicted values
#     series:dataset with timeseries
#     model:fitted SARIMA model
#     n_steps:number of steps to predict in the future
#     """
#     # adding model values
#     data = series.copy()
#     data.columns = ['actual']
#     data['arima_model']=model.fittedvalues
#     # making a shift on s+d steps, because these values were unobserved by the model due the differentiating
#     data['arima_model'][:s+d]=np.nan
#
#     # forecasting on n_steps forward
#     forecast = model.predict(start=data.shape[0],end=data.shape[0]+n_steps)
#     forecast = data.arima_model.append(forecast)
#     # calculate error, again having shifted on s+d steps from the beginning
#     error = mean_absolute_percentage_error(data['actual'][s+d:], data['arima_model'][s+d:])
#
#     plt.figure(figsize=(15,7))
#     plt.title('Mean Absolute Percentage Error: {0:.2f}%'.format(error))
#     plt.plot(forecast,color='r',label='model')
#     plt.axvspan(data.index[-1],forecast.index[-1], alpha=0.5,color='lightgrey')
#     plt.plot(data.actual,label='actual')
#     plt.legend()
#     plt.grid(True)
# plotSARIMA(ads, best_model, 50)
# plt.show()
# # 对比其他机器学习模型
# # ====================================================
# data = pd.DataFrame(ads.Ads.copy())
# data.columns=['y']
# # Adding the lag of the target variable from 6 setps back up to 24
# for i in range(6,25):
#     data['lag_{}'.format(i)]=data.y.shift(i)
# print(data.tail(7))
#
# from sklearn.linear_model import LinearRegression
# from sklearn.linear_model import LogisticRegression
# from sklearn.svm import SVR
# from sklearn.tree import DecisionTreeRegressor
# from sklearn.ensemble import RandomForestRegressor
# from sklearn.model_selection import cross_val_score
#
# tscv = TimeSeriesSplit(n_splits=5)
#
# def timeseries_train_test_split(X,y,test_size):
#     """
#     Perform train-test split with respect to time series structure
#     """
#     # get the index after which test set starts
#     test_index = int(len(X)*(1-test_size))
#     X_train = X.iloc[:test_index]
#     y_train = y.iloc[:test_index]
#     X_test = X.iloc[test_index:]
#     y_test = y.iloc[test_index:]
#     return X_train,X_test,y_train,y_test
# y = data.dropna().y
# X = data.dropna().drop(['y'],axis=1)
#
# # reserve 30% of data for testing
# X_train, X_test, y_train, y_test =timeseries_train_test_split(X,y,test_size=0.3)
# lr = LinearRegression()
# lr.fit(X_train, y_train)
# svr = SVR(kernel='poly')
# svr.fit(X_train, y_train)
# lgr = LogisticRegression()
# lgr.fit(X_train, y_train)
# dt = DecisionTreeRegressor()
# dt.fit(X_train, y_train)
# rfr = RandomForestRegressor()
# rfr.fit(X_train, y_train)
# def plotModelResults(model, X_train=X_train, X_test=X_test, plot_intervals=False, plot_anomalies=False):
#     """
#     Plot modelled vs fact values, prediction intervals and anomalies
#     """
#     prediction = model.predict(X_test)
#
#     plt.figure(figsize=(15,7))
#     plt.plot(prediction,'g',label='prediction', linewidth=2.0)
#     plt.plot(y_test.values, label='actual', linewidth=2.0)
#
#     if plot_intervals:
#         cv = cross_val_score(model, X_train, y_train, cv=tscv, scoring='neg_mean_absolute_error')
#         mae = cv.mean() *(-1)
#         deviation = cv.std()
#
#         scale=1.96
#         lower = prediction-(mae + scale * deviation)
#         upper = prediction + (mae + scale *deviation)
#
#         plt.plot(lower, 'r--', label='upper bond / lower bond', alpha=0.5)
#         plt.plot(upper, 'r--', alpha=0.5)
#
#     if plot_anomalies:
#         anomalies = np.array([np.nan]*len(y_test))
#         anomalies[y_test<lower] = y_test[y_test<lower]
#         anomalies[y_test>upper] = y_test[y_test>upper]
#         plt.plot(anomalies, 'o', markersize=10, label='Anomalies')
#
#     error = mean_absolute_percentage_error(prediction, y_test)
#     plt.title('Mean absolute percentage error {0:.2f}%'.format(error))
#     plt.legend(loc='best')
#     plt.tight_layout()
#     plt.grid(True)
# def plotCoefficients(model):
#     """
#     PLots sorted coefficient values of the model
#     """
#     coefs = pd.DataFrame(model.coef_, X_train.columns)
#     print()
#     coefs.columns = ['coef']
#     coefs['abs'] = coefs.coef.apply(np.abs)
#     coefs = coefs.sort_values(by='abs', ascending=False).drop(['abs'],axis=1)
#
#     plt.figure(figsize=(15, 7))
#     coefs.coef.plot(kind='bar')
#     plt.grid(True, axis='y')
#     plt.hlines(y=0,xmin=0, xmax=len(coefs), linestyles='dashed')
# #-------------------------------------------------------------------------------------
# plotModelResults(lr, plot_intervals=True)
# plotCoefficients(lr)
# plotModelResults(svr, plot_intervals=True)
# plotModelResults(lgr, plot_intervals=True)
# plotModelResults(dt, plot_intervals=True)
# plotModelResults(rfr, plot_intervals=True)
# plt.show()