const regeneratorRuntime = require('regenerator-runtime')
const tf = require('@tensorflow/tfjs-core')
//index.js
const f_s = 20
const N = 50
const denominator = 10
var a = []
var b = []
var c = []
var cnt = 0
// 权重
var weights = [[2.27749974e-01, -3.12381297e-01, 4.58542891e-02,
  -1.45878077e-01],
  [-8.57060701e-02, 2.65846938e-01, 1.92645729e-01,
    4.79373902e-01],
  [-2.68902391e-01, -4.05228771e-02, 1.34700283e-01,
  -1.69221431e-01],
  [-5.69546558e-02, 3.75737935e-01, -7.80953094e-02,
    1.93185776e-01],
  [-4.10813719e-01, -4.83279489e-02, 9.31631625e-02,
  -8.51083472e-02],
  [1.05700076e+00, 8.50735855e+00, -4.98487329e+00,
    -8.04959297e+00],
  [1.31163502e+00, 5.64480066e+00, 3.31522465e-01,
    -7.93438196e+00],
  [-1.03847933e+00, 4.33561707e+00, -2.91257882e+00,
    3.18119049e-01],
  [-6.61387920e+00, 3.70204306e+00, -1.64867854e+00,
    3.31891251e+00],
  [-8.01257896e+00, 5.59726954e+00, -3.79674244e+00,
    3.54518175e+00],
  [3.92024279e-01, -5.99073589e-01, 8.97607923e-01,
    -1.05538666e+00],
  [-1.09097995e-01, -2.52408773e-01, -1.14873007e-01,
    1.14895873e-01],
  [3.06774586e-01, -1.28188804e-01, 1.23840570e-01,
    2.57607371e-01],
  [-2.70027488e-01, 2.42887899e-01, -3.98132652e-01,
  -1.20252512e-01],
  [2.38323957e-01, -7.31676221e-02, 2.50032306e-01,
    -9.32033285e-02],
  [-3.08782077e+00, -7.86570013e-01, 2.43383616e-01,
    1.85485804e+00],
  [7.36820459e-01, -2.47347713e+00, 2.42917418e+00,
    -7.67795861e-01],
  [-3.47360164e-01, -2.13161087e+00, 2.02683926e+00,
  -9.88304764e-02],
  [1.85339510e+00, -1.78346980e+00, 1.72194898e+00,
    -1.90839839e+00],
  [1.28644061e+00, 1.55841994e+00, -9.68243003e-01,
    -1.30115080e+00],
  [-3.80962998e-01, -3.49794656e-01, 9.42453146e-01,
    4.77161765e-01],
  [1.56937212e-01, -1.35558799e-01, -2.07207441e-01,
    -3.92823131e-05],
  [9.65691209e-02, 7.30779171e-02, 6.24941289e-02,
    2.57783979e-01],
  [2.19219103e-01, 3.54547143e-01, 2.87328780e-01,
    2.42764801e-01],
  [3.73380899e-01, 6.36789948e-02, 3.60166356e-02,
    -2.44947840e-02],
  [4.81907463e+00, -3.99467039e+00, -6.57192373e+00,
    5.06728649e+00],
  [3.02169895e+00, -6.83462620e+00, -3.46571565e+00,
    5.77769423e+00],
  [-3.37135315e-01, -2.72601843e+00, 6.37527928e-02,
    2.75506830e+00],
  [4.24267262e-01, -3.42697114e-01, -2.61296344e+00,
    3.42878580e+00],
  [2.12556767e+00, 2.77660608e+00, -5.63186693e+00,
    2.42398429e+00]]






var accx = tf.tensor([0.53514099  ,0.58222961  ,0.52558899  ,0.48310852  ,0.39367676  ,0.25471497
  ,0.14547729  ,0.29527283  ,0.95800781  ,1.34013367  ,1.40887451  ,1.00642395
  ,0.20684814 ,-0.15509033 ,-0.01792908 ,-0.03469849 ,-0.03149414  ,0.21662903
  ,0.47059631  ,0.94645691  ,0.99824524  ,0.61250305  ,0.34541321  ,0.41365051
  ,0.42630005  ,0.39559937  ,0.43217468  ,0.62690735  ,0.57865906  ,0.5405426
  ,0.55970764  ,0.52430725  ,0.49845886  ,0.47769165  ,0.33256531  ,0.19586182
  ,0.1963501   ,0.48875427  ,1.22312927  ,1.71627808  ,1.41758728  ,0.97987366
  ,-0.00178528 ,-0.51344299 ,-0.13360596 ,-0.04689026  ,0.06239319  ,0.35290527
  ,0.90223694  ,1.32022095])
var accy = tf.tensor([-0.80610657 ,-0.72509766 ,-0.72819519 ,-0.66799927 ,-0.54664612 ,-0.44781494
  ,-0.41322327 ,-0.72343445 ,-1.50469971 ,-1.87513733 ,-2.05241394 ,-1.26020813,-0.52583313  ,0.00588989  ,0.00671387  ,0.14309692  ,0.24279785  ,0.23220825
  ,-2.59754944 ,-1.98562622 ,-1.6340332 ,-1.52932739 ,-1.06808472 ,-0.68389893
  ,-0.51382446 ,-0.66165161 ,-0.66023254 ,-0.79795837 ,-0.83952332 ,-0.74604797
  ,-0.78125 ,-0.80632019 ,-0.6192627 ,-0.56677246 ,-0.527771 ,-0.46887207
  ,-0.48812866 ,-0.77290344 ,-1.74317932 ,-2.39825439 ,-2.50900269 ,-1.07434082
  ,0.18751526  ,0.64733887  ,0.09559631 , 0.0242157, -0.16738892 ,-0.55465698
,-1.64344788 ,-1.7805481])
var accz = tf.tensor([-0.27578735 ,-0.32019043 ,-0.25549316 ,-0.25492859,-0.2306366 ,-0.15190125,-0.07847595 ,-0.09942627 ,-0.2802887 ,-0.41325378 ,-0.35830688 ,-0.36862183,-0.14894104  ,0.08001709  ,0.02778625  ,0.00538635 ,0.01516724 ,-0.09577942,-0.1497345 ,-0.48970032 ,-0.51824951 ,-0.30618286,-0.18063354 ,-0.25463867,-0.21374512 ,-0.15107727 ,-0.18774414 ,-0.24209595 ,-0.25357056 ,-0.29672241,-0.25674438 ,-0.20144653 ,-0.26191711 ,-0.23901367 ,-0.19309998 ,-0.11531067,-0.15823364 ,-0.28660583 ,-0.64447021 ,-0.82400513 ,-0.62037659 ,-0.30554199,0.54899597  ,0.58287048  ,0.16098022 ,-0.06620789, -0.07855225 ,-0.34910583,-0.70195007 ,-0.84954834])
const im = tf.tensor([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0])
//index.js
Page({
  data:{
    first_cnt:0,
    second_cnt:0,
    third_cnt:0,
    forth_cnt:0,
    coun : 0,
    accX:[],
    accY:[],
    accZ:[]
  },
  onReady() {
    wx.startAccelerometer({
      interval: 'ui'
    })
  },
  // 处理数据：快速傅里叶变换fft
  get_fft_values: function (y_values) {
    f_values = tf.linspace(0.0, 20 / 2.0, 50 / 2)
    fft_values_ = tf.real(tf.complex(y_values, im).fft())
    // console.log(tf.tensor(fft_values_.arraySync()[0]))
    tf.tensor(fft_values_.arraySync()[0]).slice([0], [25]).print()
    fft_value = tf.mul(tf.scalar(0.04), tf.abs(tf.tensor(fft_values_.arraySync()[0]).slice([0], [25])))
    // console.log(f_values)
    return {
      x: f_values,
      y: fft_value
    }
  },
  // 处理数据：峰值检测
  detect_peaks: function(y_value, mph){
    var y = y_value.arraySync()
    var start = 1
    var end = y.length - 2
    var peaks = []
    for(var i = start;i<=end;i++){
      var curr = y[i];
      var last = y[i-1];
      var next = y[i+1];
      if(curr>next && curr>last && curr>mph){
        peaks.push(i);
      }
    }
    return peaks
  },
  // 处理数据：获取前n个峰值的index
  get_first_n_peaks:function(x_,y_){

    if(x_.length>=5){
      var xP = x_.slice(0, 5)
      var yP = y_.slice(0, 5)
      return {
        xP ,
        yP 
      }
    }
    else{
      var missing = 5 - x_.length
      for(var i=0;i<missing;i++){
        x_.push(0)
        y_.push(0)
      }
      xP = x_
      yP = y_
      return{
        xP,
        yP
      }
    }
  },
  // 处理数据：获取特征
  get_features:function(x_v, y_v, mph){
    indices_peaks = this.detect_peaks(y_v, mph)
    peaks = this.copy(x_v, y_v, indices_peaks)
    n_peaks = this.get_first_n_peaks(peaks.xx, peaks.yy)
    var feature = n_peaks.xP.concat(n_peaks.yP)
    return feature
  },
  // 处理数据：提取特征
  extract_features:function(datax,datay,dataz){
    var signal_min = datax.min().arraySync()
    var signal_max = datax.max().arraySync()
    var mph = signal_min + (signal_max - signal_min) / denominator
    var fea = this.get_features(this.get_fft_values(datax).x,this.get_fft_values(datax).y,mph)

    signal_min = datay.min().arraySync()
    signal_max = datay.max().arraySync()
    mph = signal_min + (signal_max - signal_min) / denominator
    var fea1 = this.get_features(this.get_fft_values(datay).x, this.get_fft_values(datay).y, mph)

    fea.push.apply(fea,fea1)
  
    signal_min = dataz.min().arraySync()
    signal_max = dataz.max().arraySync()
    mph = signal_min + (signal_max - signal_min) / denominator
    var fea2 = this.get_features(this.get_fft_values(dataz).x, this.get_fft_values(dataz).y, mph)
    fea.push.apply(fea,fea2)
    return fea
  },
  getMaxIndex: function (arr) {
    var max = arr[0];
    var index = 0;
    for (var i = 0; i < arr.length; i++) {
      if (max < arr[i]) {
        max = arr[i];
        index = i;
      }
    }
    return index;
  },
  copy: function(x,y,index){
    var xl = x.arraySync()
    var yl = y.arraySync()
    var xx = []
    var yy = []
    for(i in index){
      xx.push(xl[index[i]])
      yy.push(yl[index[i]])
    }
    return{
      xx,yy
    }
  },
  // softmax
  get_softmax_value: function(arr){
    var len = arr.length
    var out = []
    var soft_sum = 0
    for(var i =0;i<len;i++){
      out.push(Math.pow(Math.E,arr[i]))
      soft_sum = soft_sum + out[i]
      console.log(out[i])
    }
    for (var i = 0; i < len; i++) {
      out[i] = out[i] / soft_sum
    }
    return out
  },
  // 预测
  prediction:function(m, b){
    var that = this
    switch (m) {
      case 0:
        var num = 0
        for(var i=0;i<b.length-1;i++)
        {
          if((b[i]-(-1.2))*(b[i+1]-(-1.2))<0){
            num++;
          }
        }
        num = Math.round(num/4)
        var first = that.data.first_cnt + num;
        that.setData({
          first_cnt: first
        });
        break;
      case 1:
        var num = 0
        for (var i = 0; i < b.length - 1; i++) {
          if ((b[i] - (0.7)) * (b[i + 1] - (0.7))<0) {
            num++;
          }
        }
        num = Math.round(num/2)
        var first = that.data.second_cnt + num;
        that.setData({
          second_cnt: first
        });
        break;
      case 2:
        var num = 0
        for (var i = 0; i < b.length - 1; i++) {
          if ((b[i] - (-1.5)) * (b[i + 1] - (-1.5))<0) {
            num++;
          }
        }
        num = Math.round(num / 4)
        var first = that.data.third_cnt + num;
        that.setData({
          third_cnt: first
        });
        break;
      case 3:
        var num = 0
        for (var i = 0; i < b.length - 1; i++) {
          if ((b[i] - (1)) * (b[i + 1] - (1))<0) {
            num++;
          }
        }
        num = Math.round(num / 2)
        var first = that.data.forth_cnt +num;
        that.setData({
          forth_cnt: first
        });
        break;
    }
  },
  // 清除
  pred:function(){
    this.setData({
      features:0,
      coun : 0,
      first_cnt: 0,
      second_cnt: 0,
      third_cnt: 0,
      forth_cnt: 0
    })
  },
  // 停止收集数据
  stop:function(){
    wx.offAccelerometerChange()
    this.setData({
      accX:a,
      accY:b,
      accZ:c,
      coun:cnt
    })
  },
  //数据处理
  dataPro:function(a,b,c){
    var accx = []
    var accy = []
    var accz = []
    for(var li = 0;li<Math.floor(a.length/50);li++){
      accx.push(a.slice(50 * li, 50 * (li + 1)))
      accy.push(b.slice(50 * li, 50 * (li + 1)))
      accz.push(c.slice(50 * li, 50 * (li + 1)))
    }
    return{
      accx,accy,accz
    }
  },
  //开始
  getdata:function () {
    var ama = 0
    var that = this
    a = that.data.accX
    b = that.data.accY
    c = that.data.accZ
    cnt = that.data.coun
    wx.onAccelerometerChange(function (res) {
      a[cnt] = res.x 
      b[cnt] = res.y
      c[cnt] = res.z
      cnt++
      that.setData({
        coun: cnt
      })
      if (cnt == 200) {
        ama++
        cnt = 0
        wx.vibrateLong()
        var data = that.dataPro(a,b,c)
        for(var mi = 0;mi<Math.floor(a.length/50); mi++){
          var jj = that.extract_features(tf.tensor(data.accx[mi]), tf.tensor(data.accy[mi]), tf.tensor(data.accz[mi]))
          that.setData({
            features: jj
          })
          var pp = jj
          var out = []
          var temp = 0
          for (i = 0; i < 4; i++) {
            temp = 0
            for (j = 0; j < pp.length; j++) {
              temp = temp + pp[j] * weights[j][i]
            }
            out.push(temp)
          }
          // console.log(out)
          //activation
          var predi = that.get_softmax_value(out)
          var m = that.getMaxIndex(predi)
          that.setData({
            prediction: predi,
          })
          that.prediction(m, data.accy[mi]);
        }
      }
    })
  }
})