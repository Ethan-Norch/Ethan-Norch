import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.linear_model import Perceptron
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import classification_report
import matplotlib.pyplot as plt
from scipy.fftpack import fft
from scipy.signal import welch
from detecta import detect_peaks
import tensorflow as tf
import time
accX = pd.read_csv('HIITDATA/180Jump/database_export-Wmbiq29UXbKs.csv',usecols=[0]).values.tolist()
accY = pd.read_csv('HIITDATA/180Jump/database_export-Wmbiq29UXbKs.csv',usecols=[1]).values.tolist()
accZ = pd.read_csv('HIITDATA/180Jump/database_export-Wmbiq29UXbKs.csv',usecols=[2]).values.tolist()
HalfaccX = pd.read_csv('HIITDATA/Halfburgee/database_export-LQQR8rAaMADk.csv',usecols=[0]).values.tolist()
HalfaccY = pd.read_csv('HIITDATA/Halfburgee/database_export-LQQR8rAaMADk.csv',usecols=[1]).values.tolist()
HalfaccZ = pd.read_csv('HIITDATA/Halfburgee/database_export-LQQR8rAaMADk.csv',usecols=[2]).values.tolist()
LateaccX = pd.read_csv('HIITDATA/lateraloverweights/database_export-lkZIlDDjXvPs.csv',usecols=[0]).values.tolist()
LateaccY = pd.read_csv('HIITDATA/lateraloverweights/database_export-lkZIlDDjXvPs.csv',usecols=[1]).values.tolist()
LateaccZ = pd.read_csv('HIITDATA/lateraloverweights/database_export-lkZIlDDjXvPs.csv',usecols=[2]).values.tolist()
SquaaccX = pd.read_csv('HIITDATA/Squatjack/database_export-KUeMAymqxDRy.csv',usecols=[0]).values.tolist()
SquaaccY = pd.read_csv('HIITDATA/Squatjack/database_export-KUeMAymqxDRy.csv',usecols=[1]).values.tolist()
SquaaccZ = pd.read_csv('HIITDATA/Squatjack/database_export-KUeMAymqxDRy.csv',usecols=[2]).values.tolist()

TaccX = pd.read_csv('HIITDATA/TestSet/180Jump/database_export-A27V8bsgeRSA.csv',usecols=[0]).values.tolist()
TaccY = pd.read_csv('HIITDATA/TestSet/180Jump/database_export-A27V8bsgeRSA.csv',usecols=[1]).values.tolist()
TaccZ = pd.read_csv('HIITDATA/TestSet/180Jump/database_export-A27V8bsgeRSA.csv',usecols=[2]).values.tolist()
THalfaccX = pd.read_csv('HIITDATA/TestSet/Halfburgee/database_export-urvIm_hLS_p8.csv',usecols=[0]).values.tolist()
THalfaccY = pd.read_csv('HIITDATA/TestSet/Halfburgee/database_export-urvIm_hLS_p8.csv',usecols=[1]).values.tolist()
THalfaccZ = pd.read_csv('HIITDATA/TestSet/Halfburgee/database_export-urvIm_hLS_p8.csv',usecols=[2]).values.tolist()
TLateaccX = pd.read_csv('HIITDATA/TestSet/Lateraloverweights/database_export-3VIUZ7FB4NAz.csv',usecols=[0]).values.tolist()
TLateaccY = pd.read_csv('HIITDATA/TestSet/Lateraloverweights/database_export-3VIUZ7FB4NAz.csv',usecols=[1]).values.tolist()
TLateaccZ = pd.read_csv('HIITDATA/TestSet/Lateraloverweights/database_export-3VIUZ7FB4NAz.csv',usecols=[2]).values.tolist()
TSquaaccX = pd.read_csv('HIITDATA/TestSet/Squatjack/database_export-0ia2NKqY4GxT.csv',usecols=[0]).values.tolist()
TSquaaccY = pd.read_csv('HIITDATA/TestSet/Squatjack/database_export-0ia2NKqY4GxT.csv',usecols=[1]).values.tolist()
TSquaaccZ = pd.read_csv('HIITDATA/TestSet/Squatjack/database_export-0ia2NKqY4GxT.csv',usecols=[2]).values.tolist()
def datPro(a):
    all_data = []
    for i in a:
        all_data.append("".join(i))
    acc_data = []
    for i in all_data:
        acc_data.append(i.split(","))
    Acc_data=[]
    for i in acc_data:
        i.pop(0)
        i.pop(len(i) - 1)
        i = list(map(float, i))
        i = np.array(i)
        Acc_data.append(i)
    return Acc_data
def datPlot(acc_data):
    for i in acc_data:
        rate = 20  # 采样率
        fft_size = 1050  # FFT取样长度
        t = np.arange(0, 50, 1.0 / rate)  # np.arange(起点，终点，间隔)
        x = i[50:fft_size]  # 从波形数据中取样fft_size个点进行运算

        xf = np.fft.rfft(i) / fft_size
        freqs = np.linspace(0, rate * 10, 51)
        xfp = 20 * np.log10(np.clip(np.abs(xf), 1e-20, 1e100))
        plt.figure(figsize=(8, 4))
        plt.subplot(211)
        plt.plot(t[:fft_size], x)
        plt.xlabel(u"时间(秒)", fontproperties='FangSong')
        plt.title(u"180Jump_AccX", fontproperties='FangSong')
        plt.show()
act_list = [accX,accY,accZ,HalfaccX,HalfaccY,HalfaccZ,LateaccX,LateaccY,LateaccZ,SquaaccX,SquaaccY,SquaaccZ]
Tact_list = [TaccX,TaccY,TaccZ,THalfaccX,THalfaccY,THalfaccZ,TLateaccX,TLateaccY,TLateaccZ,TSquaaccX,TSquaaccY,TSquaaccZ]
TestSet = np.zeros((480,50,3))
Tlabel = np.zeros(480)
TrainSet = np.zeros((1600,50,3))
label=np.zeros(1600)
for index,act in enumerate(act_list):
    lab = index//3
    win_num = int((index//3 * 400))
    x = index%3
    act = datPro(act)
    for each_act in act:
        a = each_act[50:1050]
        for i in range(40):
            A = a[i * 25:i * 25 + 50]
            for index,value in enumerate(A):
                TrainSet[win_num][index][x] = A[index]
            label[win_num] = lab
            win_num += 1
for index,act in enumerate(Tact_list):
    lab = index//3
    win_num = int((index//3 * 120))
    x = index%3
    act = datPro(act)
    for each_act in act:
        a = each_act[50:1050]
        for i in range(40):
            A = a[i * 25:i * 25 + 50]
            for index,value in enumerate(A):
                TestSet[win_num][index][x] = A[index]
            Tlabel[win_num] = lab
            win_num += 1
# 信号可视化（单条数据）
def showSignal(N):
    f_s = 20
    N = 50
    x_value = TrainSet[N,:,0]
    y_value = TrainSet[N,:,1]
    z_value = TrainSet[N,:,2]

    def sigPlot(x_value, y_value, z_value):
        f_value = np.linspace(0.0, 2.5, 50)
        plt.plot(f_value, x_value, linestyle='-', color='red', label='accX')
        plt.plot(f_value, y_value, linestyle='-', color='blue', label='accY')
        plt.plot(f_value, z_value, linestyle='-', color='green', label='accZ')
        plt.xlabel('Time[sec]',fontsize=16)
        plt.ylabel('Amplitude',fontsize=16)
        plt.show()
    def fftPlot(x_value, y_values, z_value, N, f_s):
        f_values = np.linspace(0.0, f_s / 2.0, N // 2)
        fft_values_ = fft(y_values)
        fft_values_x = fft(x_value)
        fft_values_z = fft(z_value)
        fft_value = 2.0 / N * np.abs(fft_values_[0:N // 2])
        fft_valuex = 2.0 / N * np.abs(fft_values_x[0:N // 2])
        fft_valuez = 2.0 / N * np.abs(fft_values_z[0:N // 2])
        plt.plot(f_values, fft_valuex, linestyle='-', color='red', label='fftX')
        plt.plot(f_values, fft_value, linestyle='-', color='blue', label='fftY')
        plt.plot(f_values, fft_valuez, linestyle='-', color='green', label='fftZ')
        plt.xlabel('Frequency [Hz]', fontsize=16)
        plt.ylabel('Amplitude', fontsize=16)
        plt.title("Frequency domain of the signal", fontsize=16)
        plt.show()
    def psdPlot(x_value, y_values, z_value, f_s):
        f_values, psd_values = welch(x_value, fs=f_s)
        plt.plot(f_values, psd_values, linestyle='-', color='red', label='psdX')
        f_values, psd_values = welch(y_values, fs=f_s)
        plt.plot(f_values, psd_values, linestyle='-', color='blue', label='psdY')
        f_values, psd_values = welch(z_value, fs=f_s)
        plt.plot(f_values, psd_values, linestyle='-', color='green', label='psdZ')
        plt.xlabel('Frequency [Hz]')
        plt.ylabel('PSD [V**2 / Hz]')
        plt.show()
    def autoPlot(x_value, y_values, z_value, N, f_s):
        result = np.correlate(x_value, x_value, mode='full')
        autocorr_values = result[len(result) // 2:]
        t_values = np.array([1.0 * jj / f_s for jj in range(0, N)])
        plt.plot(t_values, autocorr_values, linestyle='-', color='red', label='autoX')

        result = np.correlate(y_values, y_values, mode='full')
        autocorr_values = result[len(result) // 2:]
        t_values = np.array([1.0 * jj / f_s for jj in range(0, N)])
        plt.plot(t_values, autocorr_values, linestyle='-', color='blue',label='autoY')

        result = np.correlate(z_value, z_value, mode='full')
        autocorr_values = result[len(result) // 2:]
        t_values = np.array([1.0 * jj / f_s for jj in range(0, N)])
        plt.plot(t_values, autocorr_values, linestyle='-', color='green', label='autoZ')

        plt.xlabel('time delay [s]')
        plt.ylabel('Autocorrelation amplitude')
        plt.show()

    sigPlot(x_value, y_value, z_value)
    fftPlot(x_value, y_value, z_value, N, f_s)
    psdPlot(x_value, y_value, z_value, f_s)
    autoPlot(x_value, y_value, z_value,N,f_s)
# 数据乱序
def randomize(dataset, labels):
    permutation = np.random.permutation(labels.shape[0])
    shuffled_dataset = dataset[permutation, :, :]
    shuffled_labels = labels[permutation]
    return shuffled_dataset, shuffled_labels
train_signals, train_labels = randomize(TrainSet ,label)
test_signals, test_labels = randomize(TestSet, Tlabel)
# 特征
f_s = 20
N = 50
denominator = 10
def get_fft_values1(y_values, N, f_s):
    f_values = np.linspace(0.0, f_s/2.0, N//2)
    fft_values_ = fft(y_values)
    fft_values = 2.0/N * np.abs(fft_values_[0:N//2])
    return f_values, fft_values
def get_fft_values(y_values, N, f_s):
    f_values = tf.linspace(0.0, f_s / 2.0, N // 2)
    fft_values_ = tf.math.real(tf.signal.fft(y_values))
    fft_values = 2.0 / N * tf.abs(tf.slice(fft_values_, [0], [N // 2]))
    return np.array(f_values), np.array(fft_values)
def get_psd_values(y_values, N, f_s):
    f_values, psd_values = welch(y_values, fs=f_s)
    return f_values, psd_values
def get_autocorr_values(y_values, N, f_s):
    result = np.correlate(y_values, y_values, mode='full')
    autocorr_values = result[len(result) // 2:]
    x_values = np.array([1.0 * jj / f_s for jj in range(0, N)])
    return x_values, autocorr_values
def get_first_n_peaks(x, y, no_peaks=5):
    x_, y_ = list(x), list(y)
    if len(x_) >= no_peaks:
        return x_[:no_peaks], y_[:no_peaks]
    else:#少于5个peaks，以0填充
        missing_no_peaks = no_peaks-len(x_)
        return x_ + [0]*missing_no_peaks, y_ + [0]*missing_no_peaks
def get_features(x_values, y_values, mph):
    indices_peaks = detect_peaks(y_values, mph=mph)
    # print("indices_peaks are : ",indices_peaks)
    peaks_x, peaks_y = get_first_n_peaks(
        x_values[indices_peaks], y_values[indices_peaks])
    return peaks_x + peaks_y
def extract_features_labels(dataset, labels, N, f_s, denominator):
    percentile = 0
    list_of_features = []
    list_of_labels = []
    for signal_no in range(0, len(dataset)):
        features = []
        list_of_labels.append(labels[signal_no])
        for signal_comp in range(0, dataset.shape[2]):
            signal = dataset[signal_no, :, signal_comp]

            signal_min = np.nanpercentile(signal, percentile)
            signal_max = np.nanpercentile(signal, 100 - percentile)
            # ijk = (100 - 2*percentile)/10
            # set minimum peak height
            mph = signal_min + (signal_max - signal_min) / denominator
            # if signal_no == 2:
            #     print("mph={0}, signal_max={1}, signal_min={2}".format(mph, signal_max, signal_min))
            # features += get_features(*get_psd_values(signal, N, f_s), mph)
            features += get_features(*get_fft_values(signal, N, f_s), mph)
            # if signal_no == 2:
            #     print("fft",get_fft_values(signal, N, f_s))
            #     print("fft1",get_fft_values1(signal, N, f_s))
                # print(len(features), get_fft_values(signal, N, f_s))
            # features += get_features(*get_autocorr_values(signal, N, f_s), mph)
        list_of_features.append(features)
    return np.array(list_of_features), np.array(list_of_labels)
print(train_signals.shape)
X_train, Y_train = extract_features_labels(train_signals, train_labels, N, f_s, denominator)
print(X_train.shape, Y_train.shape)
X_test, Y_test = extract_features_labels(test_signals, test_labels, N, f_s, denominator)
# print(test_signals[1,:,0])
# print(test_signals[1,:,1])
# print(test_signals[1,:,2])
# print(Y_train)

# print(X_test.shape, Y_test.shape)
# print(X_train)
# print(Y_train)
print("==============RandomForest Classifier===============")
start = time.clock()
clf = RandomForestClassifier(n_estimators=1000)
clf.fit(X_train, Y_train)
print("Accuracy on training set is : {}".format(clf.score(X_train, Y_train)))
print("Accuracy on test set is : {}".format(clf.score(X_test, Y_test)))
Y_test_pred = clf.predict(X_test)
print(classification_report(Y_test, Y_test_pred))
print("Time on RF is : {}".format(time.clock()-start))
# print(clf)
# print("==============Perception Classifier===============")
# start = time.clock()
# ppn = Perceptron
# ppn.fit(X_train, Y_train)
# print("Accuracy on training set is : {}".format(ppn.score(X_train, Y_train)))
# print("Accuracy on test set is : {}".format(ppn.score(X_test, Y_test)))
# Y_test_pred = ppn.predict(X_test)
# print(Y_test_pred)
# print(classification_report(Y_test, Y_test_pred))
# print("Time on ppn is : {}".format(time.clock()-start))
# print(ppn)
# print("==============Logistic Regression===============")
# start = time.clock()
# clf = LogisticRegression(random_state=0).fit(X_train, Y_train)
# print("Accuracy on training set is : {}".format(clf.score(X_train, Y_train)))
# print("Accuracy on test set is : {}".format(clf.score(X_test, Y_test)))
# Y_test_pred = clf.predict(X_test)
# print(classification_report(Y_test, Y_test_pred))
# print("Time on LR is : {}".format(time.clock()-start))
# print("==============DecisionTree Classifier===============")
# start = time.clock()
# clf = DecisionTreeClassifier().fit(X_train, Y_train)
# print("Accuracy on training set is : {}".format(clf.score(X_train, Y_train)))
# print("Accuracy on test set is : {}".format(clf.score(X_test, Y_test)))
# Y_test_pred = clf.predict(X_test)
# print(classification_report(Y_test, Y_test_pred))
# print("Time on DT is : {}".format(time.clock()-start))
# print("==============KNeighbors Classifier===============")
# start = time.clock()
# clf = KNeighborsClassifier(8).fit(X_train, Y_train)
# print("Accuracy on training set is : {}".format(clf.score(X_train, Y_train)))
# print("Accuracy on test set is : {}".format(clf.score(X_test, Y_test)))
# Y_test_pred = clf.predict(X_test)
# print(classification_report(Y_test, Y_test_pred))
# print("Time on KNN is : {}".format(time.clock()-start))

# ab = np.array([0.12, 0.34, 0.12, 0.65, 0.23, 0.75, 0.54, 0.78, 0.23, 0.76, 0.12, 0.12, 0.76, 0.43, 0.12])
# indices_peaks = detect_peaks(ab,mph = 0.45)
# print

from keras.models import Sequential
from keras.layers import Dense, Activation
import numpy as np
from keras import optimizers
from keras.utils import to_categorical
import tensorflowjs as tfjs
Y_train = to_categorical(Y_train)
Y_test = to_categorical(Y_test)
# x_train = np.array([[1,1], [1,0], [0,0], [0,1]])
# y_train = np.array([[0],[1],[0],[1]])
# print(x_train, y_train)
#
# # add models
# model = Sequential()
# model.add(Dense(units = 20, input_dim=2))
# model.add(Activation("relu"))
# model.add(Dense(units=1))
# model.add(Activation("sigmoid"))
#
# model.compile(loss="binary_crossentropy", optimizer="sgd", metrics=['accuracy'])
#
# hist = model.fit(x_train, y_train, epochs=1000)
# plt.scatter(range(len(hist.history['loss'])), hist.history['loss'])
#
# loss_metrics = model.evaluate(x_train,y_train)
# print(loss_metrics)
# plt.show()


# x_train1 = 100*np.random.random((100, 2))
# x_train2 = [-100, 100]*np.random.random((100, 2))
# x_train3 = -100*np.random.random((100, 2))
# x_train4 = [100, -100]*np.random.random((100, 2))
# x_train = np.concatenate((x_train1, x_train2, x_train3, x_train4))
# y_train = np.array([[1, 0, 0, 0]*100 + [0, 1, 0, 0]*100 + [0, 0, 1, 0]*100 + [0, 0, 0, 1]*100])
# y_train = y_train.reshape((400, 4))
#
# print(x_train, y_train)
# x_test1 = 100*np.random.random((100, 2))
# x_test2 = [-100, 100]*np.random.random((100, 2))
# x_test3 = -100*np.random.random((100, 2))
# x_test4 = [100, -100]*np.random.random((100, 2))
# x_test = np.concatenate((x_test1, x_test2, x_test3, x_test4))
# y_test = y_train

model = Sequential()
model.add(Dense(4, input_dim=30, activation=None, use_bias=False, name='dense1'))
model.add(Activation('softmax'))

ada = optimizers.Adagrad(lr=0.1, epsilon=1e-8)
model.compile(optimizer=ada, loss='categorical_crossentropy', metrics=['accuracy'])
ly = []
# for i in range(10):
model.fit(X_train, Y_train, epochs=200, shuffle=False, )
    # ly.append(model.layers[0].get_weights())
#
score = model.evaluate(X_test, Y_test)
print('loss:', score[0], '\t\taccuracy:', score[1])
# print(np.array(ly).shape)
# for i in range(10):
#     print('first weight:\t', ly[i][0][0], '\t\tsecond weight:\t', ly[i][0][1])
print(Y_test[0:5])
y = model.predict(X_test[0:5])
# print(X_test[1])
print(y)
# tfjs.converters.save_keras_model(model, 'HIITDATA/Model')
# print(model.summary())
weights = model.get_layer('dense1').get_weights()
print(weights)
# xxx = np.array(X_test[0])
#
# we = np.array(weights)[0,:,:]
# print(xxx)
# print("weights are /n",we)
# print(list(np.dot(xxx,we)))
# a = list(np.dot(xxx,we))
# import math
# def softmax(list):
#     """
#     softmax计算公式函数
#     :param list:list
#     :return:
#     """
#     outMatrix = []
#     m = len(list)
#     # print(m)
#     soft_sum = 0
#     for idx in range(m):
#         outMatrix.append(math.exp(list[idx]))  #求幂运算，取e为底的指数计算变成非负
#         soft_sum +=outMatrix[idx]   #求和运算
#     for idx in range(m):
#         outMatrix[idx] = outMatrix[idx] /soft_sum #然后除以所有项之后进行归一化
#     return outMatrix
# print(softmax(a))
