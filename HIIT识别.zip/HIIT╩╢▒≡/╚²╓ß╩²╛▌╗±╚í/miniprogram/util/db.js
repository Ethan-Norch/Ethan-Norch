const db = wx.cloud.database();

/**
 * response code
 * 20x:success
 * 40x:fail
 */
const resCode={
  200:"success",
  401:"prameters error",
}

const collectionList=[
  "180Jump",
  "HalfBurpee",
  "LateralAbHop",
  "LateralHopOverWeights",
  "SquatJack",
]
const command=db.command;
const add = (collection,data)=>{
  return new Promise((resolve,reject)=>{
    if(!exist(collection)||data==null){
      reject(401,resCode[401]);
      return;
    }
    db.collection(collection).add({
      data:data
    }).then(res=>{
      data._id=res;
      resolve(data);
    }).catch((code,msg)=>{
      reject(code,msg);
    });
  });
}
const find = (collection, _id) => {
  return new Promise((resolve, reject) => {
    if (!exist(collection) || _id == null) {
      reject(401, resCode[401]);
    }

    db.collection(collection).doc(_id).get().then(res => {
      resolve(res.data);
    }).catch((code, msg) => {
      reject(code, msg);
    });
  });
}

const update = (collection, _id, data) => {
  return new Promise((resolve, reject) => {
    if (!exist(collection)) {
      reject(401, resCode[401]);
    }
    db.collection(collection).doc(_id).update({
      data: data
    }).then(res => {
      resolve(res);
    }).catch((code, msg) => {
      reject(code, msg);
    });
  });
}

const exist = (collection) => {
  // forEach 无法跳出，用some代替测试
  let exist = false;
  collectionList.some((value, _) => {
    if (value == collection) {
      exist = true;
      return true;
    }
  });

  return exist;
}

module.exports={
  db:db,
  command: command,
  resCode: resCode,
  add: add,
  find: find,
  update: update,
}