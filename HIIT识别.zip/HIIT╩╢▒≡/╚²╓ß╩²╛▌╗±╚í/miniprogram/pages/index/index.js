//index.js
const db=wx.cloud.database()
const app = getApp()
var x = new Array();
var y = new Array();
var z = new Array();
var cnt = 0;
var countStartSec = 3 * 1000;
var actSec = 40 * 1000;
function actcnt(that){
  if(actSec<=0){
    that.setData({
      clock:"stop!",
      end:0,
      jamed:false,
      showWarning: false,
      warning: '',
    })
    actSec = 40 * 1000;
    wx.vibrateLong();
    return 0;
  }
  that.setData({
    clock: dateformat(actSec)
  });
  setTimeout(function () {
    actSec -= 10;
    actcnt(that);
  }, 10)
}
function countdown(that){
  if(countStartSec<=0){
    that.setData({
      clock:"Stop!"
    })
    countStartSec=3*1000;
    actcnt(that);
    return 1;
  }
  that.setData({
    clock: dateformat(countStartSec)
  });
  setTimeout(function(){
    countStartSec-=10;
    countdown(that);
  },10)
}
function dateformat(micro_second) {
  // 秒数
  var second = Math.floor(micro_second / 1000);
  // 小时位
  var hr = Math.floor(second / 3600);
  // 分钟位
  var min = Math.floor((second - hr * 3600) / 60);
  // 秒位
  var sec = (second - hr * 3600 - min * 60);// equal to => var sec = second % 60;
  // 毫秒位，保留2位
  var micro_sec = Math.floor((micro_second % 1000) / 10);
  return hr + ":" + min + ":" + sec + ":" + micro_sec;
}
Page({
  /**
   * 页面的初始数据
   */
  data: {
    showWarning:false,
    warning:'',
    jamed:false,
    end:1,
    clock:'',
    rotateXY:0,
    rotateYZ:0,
    rotateZX:0,
    degreesXY:0,
    degreesYZ:0,
    degreesZY:0,
    cnt:0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  jump:function(e){
    if(this.data.jamed==true)
    {
      this.setData({
        showWarning:true,
        warning:"Another action is on going, please act one each time",
      })
      return 0;
    }
    this.setData({
      end:1,
      jamed:true,
    });
    countdown(this);
    cnt = 0;
    x = []
    y = []
    z = []
    var that = this;
    if(this.data.end==1)
    {
      wx.startAccelerometer({
        interval: 'ui'
      });
      wx.onAccelerometerChange(function(res){
        x[cnt]=res.x;
        y[cnt]=res.y;
        z[cnt]=res.z;
        cnt++;
        that.setData({
          rotateXY: res.x,
          rotateYZ: res.y,
          rotateZX: res.z,
          cnt:cnt
        })
        if(that.data.end==0)
        {
          that.setData({
            jamed: false,
            showWarning: false,
            warning: '',
          })
          wx.stopAccelerometer();
          db.collection('Jump').add({
            data:{
              accX:x,
              accY:y,
              accZ:z,
            },
            success:function(res){
              console.log(res)
            }
          });
          
        }
      })
    } 
  },




  halfBurpee: function (e) {
    if (this.data.jamed==true) {
      this.setData({
        showWarning: true,
        warning: "Another action is on going, please act one each time",
      })
      return 0;
    }
    this.setData({
      end: 1,
      jamed:true,
    });
    countdown(this);
    cnt = 0;
    x = [];
    y = [];
    z = [];
    var that = this;
    if (this.data.end == 1) {
      wx.startAccelerometer({
        interval: 'ui'
      });
      wx.onAccelerometerChange(function (res) {
        x[cnt] = res.x;
        y[cnt] = res.y;
        z[cnt] = res.z;
        cnt++;
        that.setData({
          rotateXY: res.x,
          rotateYZ: res.y,
          rotateZX: res.z,
          cnt: cnt
        })
        if (that.data.end == 0) {
          wx.stopAccelerometer();
          db.collection('HalfBurpee').add({
            data: {
              accX: x,
              accY: y,
              accZ: z,
            },
            success: function (res) {
              console.log(res)
            }
          })
        }
      })
    }
  },



  lateralAbHop: function (e) {
    if (this.data.jamed==true) {
      this.setData({
        showWarning: true,
        warning: "Another action is on going, please act one each time",
      })
      return 0;
    }
    this.setData({
      end: 1,
      jamed: true,
    });
    countdown(this);
    cnt = 0;
    x = [];
    y = [];
    z = [];
    var that = this;
    if (this.data.end == 1) {
      wx.startAccelerometer({
        interval: 'ui'
      });
      wx.onAccelerometerChange(function (res) {
        x[cnt] = res.x;
        y[cnt] = res.y;
        z[cnt] = res.z;
        cnt++;
        that.setData({
          rotateXY: res.x,
          rotateYZ: res.y,
          rotateZX: res.z,
          cnt: cnt
        })
        if (that.data.end == 0) {
          that.setData({
            jamed: false,
            showWarning: false,
            warning: '',
          })
          wx.stopAccelerometer();
          db.collection('LateralAbHop').add({
            data: {
              accX: x,
              accY: y,
              accZ: z,
            },
            success: function (res) {
              console.log(res)
            }
          })
        }
      })
    }
  },



  lateralHopOverWeights: function (e) {
    if (this.data.jamed==true) {
      this.setData({
        showWarning: true,
        warning: "Another action is on going, please act one each time",
      })
      return 0;
    }
    this.setData({
      end: 1,
      jamed: true,
    });
    countdown(this);
    cnt = 0;
    x = [];
    y = [];
    z = [];
    var that = this;
    if (this.data.end == 1) {
      wx.startAccelerometer({
        interval: 'ui'
      });
      wx.onAccelerometerChange(function (res) {
        x[cnt] = res.x;
        y[cnt] = res.y;
        z[cnt] = res.z;
        cnt++;
        that.setData({
          rotateXY: res.x,
          rotateYZ: res.y,
          rotateZX: res.z,
          cnt: cnt
        })
        if (that.data.end == 0) {
          that.setData({
            jamed: false,
            showWarning: false,
            warning: '',
          })
          wx.stopAccelerometer();
          db.collection('LateralHopOverWeights').add({
            data: {
              accX: x,
              accY: y,
              accZ: z,
            },
            success: function (res) {
              console.log(res)
            }
          })
        }
      })
    }
  },

  squatJack: function (e) {
    if (this.data.jamed==true) {
      this.setData({
        showWarning: true,
        warning: "Another action is on going, please act one each time",
      })
      return 0;
    }
    this.setData({
      end: 1,
      jamed: true,
    });
    countdown(this);
    cnt = 0;
    x = [];
    y = []
    z = []
    var that = this;
    if (this.data.end == 1) {
      wx.startAccelerometer({
        interval: 'ui'
      });
      wx.onAccelerometerChange(function (res) {
        x[cnt] = res.x;
        y[cnt] = res.y;
        z[cnt] = res.z;
        cnt++;
        that.setData({
          rotateXY: res.x,
          rotateYZ: res.y,
          rotateZX: res.z,
          cnt: cnt
        })
        if (that.data.end == 0) {
          wx.stopAccelerometer();
          that.setData({
            jamed: false,
            showWarning: false,
            warning: '',
          })
          db.collection('SquatJack').add({
            data: {
              accX: x,
              accY: y,
              accZ: z,
            },
            success: function (res) {
              console.log(res)
            }
          })
        }
      })
    }
  },

  
  onLoad: function (options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})